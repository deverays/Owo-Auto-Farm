# AutoOwoFarm
A Discord Selfbot That Farm OwO Cowoncy 24/7 Ban Bypassed!


# Made By TheAxes

## It Is Designed For Replit !

### its Secure | Credentials will be in env

# Features 
- [x] **Ban Bypassed**
- [x] **24/7**
- [x] **Easy To Use**
- [x] **For Replit**
- [x] **Many More +**
###### Youtube Tutorial - [Click Here](https://youtu.be/dah2MPihCqk)
###### Direct Replit Fork - [Click Here](https://replit.com/@AxeHelper/AutoOwOFarm?v=1)
# Installation 
1. **Clone This Repo To Replit**
2. **Go To Commands > secrets**
3. **Add A Env As A Key Name `Token` And Value As Your Discord Account Token -- If You Don't Know Your Token Watch my YouTube video for tutorial link below!** 
### Tutorial Of Token - [Click Here](https://youtu.be/bixC0tQl_Wg)

4. **Save It**
5. **Run The Repl**
6. **It Will Ask For You prefix | Enter An Prefix For The Bot**
7. **You Done! Type (prefix)help for help command**
8. **Use Uptimer Robot to 24/7 This Bot Or Use My Uptimer Bot Link Below!**
### Uptimer Bot Invite Link - [Click Here](https://discord.com/oauth2/authorize?client_id=1003002613098369186&permissions=8&scope=bot)
### YouTube Channel - [Click Here](https://youtube.com/channel/UCMEhNSLa2O6WQqtqpjwu-sw)
